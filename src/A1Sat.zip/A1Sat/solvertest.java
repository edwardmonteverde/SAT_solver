package A1Sat;

public class solvertest {

}
