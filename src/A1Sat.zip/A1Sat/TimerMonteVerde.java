package A1Sat;

public class TimerMonteVerde {

	private double start;
	private double stop;

	public void start() {
		this.start = System.currentTimeMillis();
	}

	public void stop() {
		this.stop = System.currentTimeMillis();
	}

	public double getDuration() {
		return this.stop - this.start;
	}

}