package A1Sat;

public class DPSolverMonteVerde {
	
	FormulaMonteVerde formula = new FormulaMonteVerde();
	
	public DPSolverMonteVerde (String inputFile){
		formula.read(inputFile);
	}

	

	public FormulaMonteVerde read(String inputFile) {
		formula.read(inputFile);
		return formula;
	}

	

	private boolean dpSolver(FormulaMonteVerde formula) {
		if (formula.isFormulaEmpty()) {
			return true;
			} 
		if (formula.hasEmptyClause()) {
			return false;
			} 
		else {
			int var = formula.firstAvailable();
			formula.assign(var, 1);

			if (dpSolver(formula)) {
				return true;
			}

			else {
				formula.unsetAndReset(var);

				formula.assign(var, -1);

				if (dpSolver(formula)) {
					return true;
				} else {
					formula.unsetAndReset(var);
					return false;
				}
			}
		}
	}
	
	
	public void solve(FormulaMonteVerde fr) {

		if (dpSolver(fr) == true) {
			System.out.println("Formula is satisfiable:");
			formula.print();
		} 
		
		else {
			System.out.println("Formula not satisfiable");
			formula.print();
		}
	}
}